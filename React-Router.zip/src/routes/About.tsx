import Menu from "../components/Menu";

export default function About() {
  return (
    <div>
      <Menu />
      <h1>About</h1>
      <p>sobre la pagina</p>
    </div>
  );
}
